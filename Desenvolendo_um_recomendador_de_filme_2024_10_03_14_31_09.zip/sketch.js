//ação,aventura,comédia,animação,fantasia,ficção-cientifica,terror,drama,artes marciais,sitcom

//homem-aranha sem volta para casa,12,ação,aventura,comédia
//segredo dos animais,Livre,animação,comédia,aventura
//vingadores guerra infinita,12,ação,aventura,fantaisa 
//vingadores ultimato,12,ação,aventura,fantasia,ficção-cientifica
//LOKI,14,ação,fantasia,ficção-cientifica
//Stranger Things,16,terror,drama,ficção-cientifica
//Cobra kai,14,ação,comédia,artes marciais
//Jovem sheldon,12,sitcom,comédia
//Capitão America guerra civil,12,ação,aventura,drama
//Doutor Estranho multiverso da loucura,14,terror,ação,fantasia

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  let recomendação = "homem-aranha sem volta para casa";
  text(recomendação, width / 2, height )
}









